( function( $ ) {

	$( document ).ready( function() {

		$( '.report-a-bug' ).on( 'click', '.show-form', function( event ) {

			// change label and switch class
			$( this ).text( settings.send_label ).removeClass( 'show-form' ).addClass( 'send-report' );

			// show textarea
			$( '.report-a-bug-message' ).slideDown( 'slow' );

		} );

		$( '.report-a-bug' ).on( 'click', '.send-report', function( event ) {

			var $button = $(this);

			// check if message is not empty
			if ( $( '.report-a-bug-message' ).val().length === 0 ) {
				$( '.report-a-bug-message' ).css( 'border', '1px solid red' );
				return false;
			} else {
				$( '.report-a-bug-message' ).css( 'border', '1px solid rgba(51, 51, 51, 0.1)' );
			}

			$button.width( $button.width() ).text( '...' ).prop( 'disabled', true );

			// set ajax data
			var data = {
				'action' : 'send_bug_report',
				'post_id': $button.data( 'post_id' ),
				'nonce'	 : $button.data( 'nonce' ),
				'report' : $( '.report-a-bug-message' ).val()
			};

			$.post( settings.ajaxurl, data, function( response ) {

				if ( response.success == true ) {

					// remove button and textarea
					$button.remove();
					$( '.report-a-bug-message' ).remove();

					// display success message
					$( '.report-a-bug-response' ).html( response.data );

				} else {

					// display error message
					$( '.report-a-bug-response' ).html( settings.error );

				}

				// enable button and revert label
				$button.text( settings.send_label ).prop( 'disabled', false );

			} );

		} );

	} );

} )( jQuery );