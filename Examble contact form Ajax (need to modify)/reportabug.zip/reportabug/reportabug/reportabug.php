<?php 
/*
Plugin Name: Report a bug
Description: Allow your visitors to report a bug in your articles
Author: Jakub Mikita
Author URI: https://underdev.it
Version: 1.0
License: GPL2
Text Domain: reportabug
*/

/**
 * Report a bug class
 */
class Report_a_bug {

	/**
	 * Constructor
	 * @return void
	 */
	public function __construct() {

		add_filter( 'the_content', array( $this, 'report_button' ) );
		
		add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ) );

		add_action( 'wp_ajax_nopriv_send_bug_report', array( $this, 'send_bug_report' ) );
		add_action( 'wp_ajax_send_bug_report', array( $this, 'send_bug_report' ) );
		
	}

	/**
	 * Adds the report button to the end of posts content
	 * @param  string $content post content
	 * @return string          content with button
	 */
	public function report_button( $content ) {

		// display button only on posts
		if ( ! is_single() ) {
			return $content;
		}

		$nonce = wp_create_nonce( 'report_a_bug_' . get_the_ID() );

		$content .= '<div class="report-a-bug">
						<button class="show-form" data-nonce="' . $nonce . '" data-post_id="' . get_the_ID() . '">' . 
							__( 'Report a bug', 'reportabug' ) . 
						'</button>
						<textarea class="report-a-bug-message" placeholder="' . __( 'Describe what\'s wrong...', 'reportabug' ) . '"></textarea>
						<p class="report-a-bug-response"></p>
					</div>';

		return $content;

	}

	/**
	 * Enqueue plugin scripts
	 * @return void
	 */
	function scripts() {

		wp_enqueue_style( 'report-a-bug', plugin_dir_url( __FILE__ ) . 'css/style.css' );

		wp_enqueue_script( 'report-a-bug', plugin_dir_url( __FILE__ ) . 'js/scripts.js', array( 'jquery' ), null, true );

		// set variables for script
		wp_localize_script( 'report-a-bug', 'settings', array(
			'ajaxurl'	 => admin_url( 'admin-ajax.php' ),
			'send_label' => __( 'Send report', 'reportabug' ),
			'error'		 => __( 'Sorry, something went wrong. Please try again', 'reportabug' )
		) );

	}

	/**
	 * Sends bug report to defined email
	 * @return void
	 */
	function send_bug_report() {

		$data = $_POST;

		// check the nonce
		if ( false == check_ajax_referer( 'report_a_bug_' . $data['post_id'], 'nonce', false ) ) {
			wp_send_json_error();
		}

		$post_title = get_the_title( intval( $data['post_id'] ) );

		$result = wp_mail( 'admin@ema.il', 'Bug report in post: ' . $post_title, sanitize_text_field( $data['report'] ) );

		if ( true == $result ) {
			wp_send_json_success( __( 'Thanks for reporting!', 'reportabug' ) );
		} else {
			wp_send_json_error();
		}

	}

}

new Report_a_bug();